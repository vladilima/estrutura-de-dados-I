package estruturas;

public class Documento {

    public String nome;
    public int tamanho;

    public Documento(String nome, int tamanho) {
        this.nome = nome;
        this.tamanho = tamanho;
    }
    
}
